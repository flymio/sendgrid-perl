# Change Log
All notable changes to this project will be documented in this file.

## [1.3] - 2015-4-29
### Added
- Support for API keys

